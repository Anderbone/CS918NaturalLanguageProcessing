Name:Jiyu yan
Student ID:1851015 

Environment: python3.7

How to use:
Move the twitter-train-data.txt and all test.txt, evaluation.py and testsets.py to this folder.

Download the 2 links, zip and  move all files to the same folder, then run classification.py


Download https://figshare.com/s/f302c9aa1fd7f099728c
this link contains
1.positve-words.txt
2.negative-words.txt
3.SentiWords_1.1.txt
4.F3.pkl
5.F4.pkl
6.F5.pkl
7.F7.pkl
8.F8.pkl
9.vector.pkl
10.X.pkl
11.LR0.pkl
12.LR1.pkl
13.LR2.pkl

Download http://yuca.test.iminds.be:8900/fgodin/downloads/word2vec_twitter_model.tar.gz
this link contains
1.word2vecReader.py : for word embedding importing
2.word2vecReaderUtils.py: for word embedding importing
3.word2vec_twitter_model.bin : pre-trained word embedding model.(4.56GB)



==========================================================================

MUST have files(doc and code from others):
twokenize.py: for twokenize, from seminar code.
word2vecReader.py : for word embedding importing.(same file in the link)
word2vecReaderUtils.py: for word embedding importing.(same file in the link)
word2vec_twitter_model.bin : pre-trained word embedding model.(4.56GB)
positve-words.txt
negative-words.txt
SentiWords_1.1.txt

==========================================================================
Optional files(run faster with these pickels, could run and produce them again):
F3.pkl
F4.pkl
F5.pkl
F7.pkl
F8.pkl
vector.pkl
X.pkl
LR0.pkl
LR1.pkl
LR2.pkl



